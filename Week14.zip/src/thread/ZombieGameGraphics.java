package thread;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class ZombieGameGraphics extends JFrame {
	boolean gameOver;				// 게임 종료
	boolean heroDead1, heroDead2; 	// 히어로가 죽을 경우 true
	boolean isRunning;				// 스레드 동작 여부 
	GraphicsHero hero = new GraphicsHero(0, 200);
	GraphicsZombie zombie1 = new GraphicsZombie(150, 205);
	GraphicsZombie zombie2 = new GraphicsZombie(300, 205);
	
	GamePanel gp = new GamePanel();	// 게임이 이루어지는 패널
	
	public ZombieGameGraphics() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400, 300);
		setVisible(true);
		this.setContentPane(gp);
		gp.setFocusable(true);
		gp.requestFocus();
	}
	
	class GamePanel extends JPanel implements KeyListener, Runnable {
		
		public GamePanel() {
			hero.dir = 1;
		
			addKeyListener(this);
			
			// 스레드 동작
			isRunning = true;
			new Thread(this).start();
		}
		
		//스레드로 동작 : 자동으로 이루어지는 부분은 스레드에 처리
		public void run() {
			while(isRunning) {
				if((heroDead1==false)&&(heroDead2==false)){
					// 주인공 움직이고 위치 업데이트
					gameOver = hero.heroUpdate();
					// 목적지에 도달해서 게임종료
					if(gameOver==true) {
						repaint();
						break;
					}
					// 좀비를 움직이고 위치 업데이트
					zombie1.randomMove();
					zombie2.randomMove();

					// 주인공과 좀비와 충돌여부 체크
					heroDead1 = zombie1.crush(hero);
					heroDead2 = zombie1.crush(hero);

					repaint();
				}

				try {
					Thread.sleep(200);
				} catch(Exception e) {
					System.out.println(e);
				}
			}
		}
	
		public void paintComponent(Graphics g) {
			// 배경 그리기
			super.paintComponent(g);
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 400, 300);
			g.setColor(Color.ORANGE);
			g.fillRect(0, 226, 400, 226);
			// 주인공 그리기
			hero.paint(g);
			// 좀비 그리기
			zombie1.paint(g);
			zombie2.paint(g);

			// 주인공이 죽었을 때 출력 메시지
			if(heroDead1||heroDead2) {
				g.setColor(Color.RED);
				g.drawString("좀비에게 잡혔습니다.", 100, 100);
				// 스레드 종료
				isRunning = false; 
			}
			// 목적지에 도착해서 게임종료될 때 출력 메시지
			if(gameOver) {
				g.setColor(Color.RED);
				g.drawString("목적지에 도착했습니다. 게임을 종료합니다.", 100, 100);
				// 스레드 종료
				isRunning = false; 
			}
		}
		
		// 내가 키보드로 히어로를 조정하는 부분
		public void keyPressed(KeyEvent e) {
			// 히어로가 죽거나 게임이 종료되거나 했을 경우 키입력을 더이상 받지 않기 위해서
			if((heroDead1 == false) && (heroDead2 == false) && (gameOver==false)) {
				if(e.getKeyCode() == KeyEvent.VK_LEFT) {
					hero.dir = 2;
					hero.moveLeft();
				}
				else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
					hero.dir = 1;
					hero.moveRight();
				}
				else if(e.getKeyCode() == KeyEvent.VK_UP) {
					hero.jump = true;
				}
				// 좀비가 움직인 후에 주인공과 충돌 체크
				heroDead1 = hero.crush(zombie1);
				heroDead2 = hero.crush(zombie2);

				repaint();
			}
		}

		public void keyReleased(KeyEvent e) { }
		
		public void keyTyped(KeyEvent e) { }
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ZombieGameGraphics().setTitle("좀비 게임");
	}
}
