
public class CarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class Tire {
	public void roll() {
		System.out.print("일반 타이어가 굴러갑니다");
	}
}

class car {
	Tire tire1 = new Tire();
	
	Tire tire2 = new Tire() {
		public void roll() {
			System.out.print("익명 자식 Tire 객체1이 굴러갑니다.");
		}
	};
}