package ch12.sec06;

public class WarapperExample {

	public static void main(String[] args) {
		//기본 자료형의 값을 포장 객체로 변환
		Integer intValue = Integer.valueOf(10);
		Double doubleValue = Double.valueOf(3.14);
		
		//포장 객체에서 기본자료형 값 얻기
		int intVal = intValue.intValue();
		double doubleVal = doubleValue.doubleValue();
		System.out.println("integer value: " + intVal);
		System.out.println("Double value: " + doubleVal);
		
		//문자열을 포장 객체로 변환
		Integer stringToint = Integer.parseInt("100");
		System.out.println("Parsed integer value: " + stringToint);
		
		//포장객체에서 문자열 얻기
		String intToString = stringToint.toString();
		System.out.println("Integer as string " + intToString);
		
	}

}
