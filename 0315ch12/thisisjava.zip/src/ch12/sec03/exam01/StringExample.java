package ch12.sec03.exam01;

public class StringExample {

	public static void main(String[] args) {
		//문자열 생성
		String str1 = "hello";
		String str2 = "World";
		
		//문자열 연결(concatenation)
		String result = str1 + ", " + str2 + "!";
		System.out.println(result);
		
		//문자열의 길이(length)
		int length = result.length();
		System.out.println("length: " + length);
		
		//특정문자 또는 부분문자열 검색(indexOf)
		int index = result.indexOf("world");
		System.out.println("index of world: " + index);
		
		
	}

}
